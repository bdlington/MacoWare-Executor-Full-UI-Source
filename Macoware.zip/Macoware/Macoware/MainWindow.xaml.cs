﻿using Microsoft.Web.WebView2.Core;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Macoware
{
    public partial class MainWindow : Window
    {
        private bool _isMaximized = false;
        private Rect _normalBounds;
        private bool _isResizing = false;
        private bool _isLoggedIn = false;
        private bool _isInitialized = false;
        private string scriptsDirectory = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Scripts");
        private string consoleFilePath;
        private FileSystemWatcher fileWatcher;
        private string lastConsoleContent = "";
        private System.Windows.Threading.DispatcherTimer consoleTimer;

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HT_CAPTION = 0x2;
        private const int WM_SYSCOMMAND = 0x112;
        private const int SC_SIZE = 0xF000;
        private const int WMSZ_BOTTOMRIGHT = 8;

        public MainWindow()
        {
            InitializeComponent();

            // setup window defaults
            this.WindowState = WindowState.Normal;
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            this.Visibility = Visibility.Visible;
            this.Opacity = 0;

            _normalBounds = new Rect(Left, Top, Width, Height);
            this.StateChanged += MacWindow_StateChanged;
            this.SizeChanged += MacWindow_SizeChanged;
            this.LocationChanged += MacWindow_LocationChanged;
            AddDropShadow();
            InitializeWindowAsync();
        }


        private async Task InitializeWindowAsync()
        {
            try
            {
                await ShowWindowWithFallback();
                await LoadLocalHtmlAsync();
                await InitializeSidebar();
                await InitializeConsole();

                _isInitialized = true;

                System.Diagnostics.Debug.WriteLine("Window initialization completed successfully");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error initializing window: {ex.Message}");

                this.Dispatcher.Invoke(() =>
                {
                    this.Opacity = 1;
                    this.Visibility = Visibility.Visible;
                });
            }
        }

        private async Task ShowWindowWithFallback()
        {
            try
            {
                await this.Dispatcher.InvokeAsync(() =>
                {
                    this.Visibility = Visibility.Visible;
                    this.WindowState = WindowState.Normal;

                    var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(300))
                    {
                        EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
                    };

                    fadeIn.Completed += (s, e) =>
                    {
                        System.Diagnostics.Debug.WriteLine("Window fade-in animation completed");
                    };

                    this.BeginAnimation(Window.OpacityProperty, fadeIn);
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Animation failed, showing window directly: {ex.Message}");
                this.Dispatcher.Invoke(() =>
                {
                    this.Opacity = 1;
                    this.Visibility = Visibility.Visible;
                    this.WindowState = WindowState.Normal;
                });
            }
        }

        private async Task LoadLocalHtmlAsync()
        {
            try
            {
                if (Editor == null)
                {
                    System.Diagnostics.Debug.WriteLine("Editor WebView2 control is null");
                    return;
                }

                // Set the environment and options to prevent white flash
                var options = CoreWebView2Environment.GetAvailableBrowserVersionString();
                var environment = await CoreWebView2Environment.CreateAsync(options: new CoreWebView2EnvironmentOptions
                {
                    AdditionalBrowserArguments = "--disable-web-security --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-renderer-backgrounding"
                });

                await Editor.EnsureCoreWebView2Async(environment);

                // Set background color BEFORE navigation to prevent white flash
                Editor.DefaultBackgroundColor = System.Drawing.Color.FromArgb(30, 30, 30);

                Editor.CoreWebView2.Settings.AreHostObjectsAllowed = true;
                Editor.CoreWebView2.Settings.IsWebMessageEnabled = true;
                Editor.CoreWebView2.Settings.IsPasswordAutosaveEnabled = false;
                Editor.CoreWebView2.Settings.IsGeneralAutofillEnabled = false;

                // Additional settings to prevent flash
                Editor.CoreWebView2.Settings.AreDevToolsEnabled = false;
                Editor.CoreWebView2.Settings.IsStatusBarEnabled = false;
                Editor.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;

                Editor.CoreWebView2.NavigationCompleted -= Editor_NavigationCompleted;
                Editor.CoreWebView2.NavigationCompleted += Editor_NavigationCompleted;

                Editor.CoreWebView2.WebMessageReceived -= Editor_WebMessageReceived;
                Editor.CoreWebView2.WebMessageReceived += Editor_WebMessageReceived;

                string editorPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin", "editor.html");
                if (System.IO.File.Exists(editorPath))
                {
                    Editor.Source = new Uri(editorPath);
                    Editor.ZoomFactor = 0.8;
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine($"Editor HTML file not found at: {editorPath}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading local HTML: {ex.Message}");
            }
        }

        private void Editor_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (e.IsSuccess)
            {
                System.Diagnostics.Debug.WriteLine("Editor WebView navigation completed successfully");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine($"Editor WebView navigation failed: {e.WebErrorStatus}");
            }
        }

        private void Editor_WebMessageReceived(object sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Message received!");

            try
            {
                string message = e.TryGetWebMessageAsString();
                System.Diagnostics.Debug.WriteLine($"Received message: {message}");

                if (string.IsNullOrWhiteSpace(message))
                {
                    System.Diagnostics.Debug.WriteLine("Warning: Received empty or null message.");
                    return;
                }

                dynamic data = Newtonsoft.Json.JsonConvert.DeserializeObject(message);

                if (data?.action == null)
                {
                    System.Diagnostics.Debug.WriteLine("Warning: 'action' field is missing in the message.");
                    return;
                }

                string action = data.action.ToString();
                System.Diagnostics.Debug.WriteLine($"Action: {action}");

                if (action == "navigate_to_home")
                {
                    NavigateToHome();
                }
                else if (action == "navigate_to_editor")
                {
                    NavigateToEditor();
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine($"Unknown action: {action}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error handling web message: {ex.Message}");
            }
        }

        private void NavigateToHome()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("Home button clicked - showing dashboard");
                Editor.Visibility = Visibility.Collapsed;
                Sidebar.Visibility = Visibility.Collapsed;
                Console.Visibility = Visibility.Collapsed;
                Dash.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error navigating to home: {ex.Message}");
            }
        }

        private void NavigateToEditor()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("Back button clicked - showing editor");
                Dash.Visibility = Visibility.Collapsed;
                Editor.Visibility = Visibility.Visible;
                Sidebar.Visibility = Visibility.Visible;
                Console.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error navigating to editor: {ex.Message}");
            }
        }


        private async Task InitializeSidebar()
        {
            try
            {
                // Create environment with additional arguments to prevent flash
                var environment = await CoreWebView2Environment.CreateAsync(options: new CoreWebView2EnvironmentOptions
                {
                    AdditionalBrowserArguments = "--disable-web-security --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-renderer-backgrounding"
                });

                await Sidebar.EnsureCoreWebView2Async(environment);

                // Set background color BEFORE navigation
                Sidebar.DefaultBackgroundColor = System.Drawing.Color.Transparent;

                // Additional settings to prevent flash
                Sidebar.CoreWebView2.Settings.AreDevToolsEnabled = false;
                Sidebar.CoreWebView2.Settings.IsStatusBarEnabled = false;
                Sidebar.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;

                Sidebar.CoreWebView2.WebMessageReceived -= OnSidebarMessageReceived;
                Sidebar.CoreWebView2.Navigate(new Uri($"file:///{Directory.GetCurrentDirectory()}/Bin/Sidebar.html").ToString());
                Sidebar.ZoomFactor = 0.9;
                Sidebar.CoreWebView2.WebMessageReceived += OnSidebarMessageReceived;

                await Task.Delay(1000);
                await SendScriptListToSidebar();
            }
            catch (Exception)
            {
            }
        }

        private async Task InitializeConsole()
        {
            // Create environment for Dash WebView
            var environment = await CoreWebView2Environment.CreateAsync(options: new CoreWebView2EnvironmentOptions
            {
                AdditionalBrowserArguments = "--disable-web-security --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-renderer-backgrounding"
            });

            await Dash.EnsureCoreWebView2Async(environment);

            // Set background colors BEFORE any navigation
            Sidebar.DefaultBackgroundColor = System.Drawing.Color.Transparent;
            Dash.DefaultBackgroundColor = System.Drawing.Color.Transparent;
            Editor.DefaultBackgroundColor = System.Drawing.Color.Transparent;
            Console.DefaultBackgroundColor = System.Drawing.Color.Transparent;

            // Additional settings for Dash to prevent flash
            Dash.CoreWebView2.Settings.AreDevToolsEnabled = false;
            Dash.CoreWebView2.Settings.IsStatusBarEnabled = false;
            Dash.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;

            Dash.CoreWebView2.WebMessageReceived -= Dash_WebMessageReceived;
            Dash.CoreWebView2.WebMessageReceived += Dash_WebMessageReceived;
            Dash.CoreWebView2.Navigate(new Uri($"file:///{Directory.GetCurrentDirectory()}/Bin/Dash.html").ToString());
            Dash.ZoomFactor = 0.8;

            try
            {
                // Create environment for Console WebView
                var consoleEnvironment = await CoreWebView2Environment.CreateAsync(options: new CoreWebView2EnvironmentOptions
                {
                    AdditionalBrowserArguments = "--disable-web-security --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-renderer-backgrounding"
                });

                await Console.EnsureCoreWebView2Async(consoleEnvironment);

                // Additional settings for Console to prevent flash
                Console.CoreWebView2.Settings.AreDevToolsEnabled = false;
                Console.CoreWebView2.Settings.IsStatusBarEnabled = false;
                Console.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;

                Console.CoreWebView2.Navigate(new Uri($"file:///{Directory.GetCurrentDirectory()}/Bin/console.html").ToString());
                Console.ZoomFactor = 0.7;

                await Task.Delay(1000);
                SetupConsoleMonitoring();
                WindowBorder.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error initializing Console: {ex.Message}");
            }
        }

        private void Dash_WebMessageReceived(object sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Dash message received!");

            try
            {
                string message = e.TryGetWebMessageAsString();
                System.Diagnostics.Debug.WriteLine($"Received dash message: {message}");

                if (string.IsNullOrWhiteSpace(message))
                {
                    System.Diagnostics.Debug.WriteLine("Warning: Received empty or null message from dash.");
                    return;
                }

                dynamic data = Newtonsoft.Json.JsonConvert.DeserializeObject(message);

                if (data?.action == null)
                {
                    System.Diagnostics.Debug.WriteLine("Warning: 'action' field is missing in the dash message.");
                    return;
                }

                string action = data.action.ToString();
                System.Diagnostics.Debug.WriteLine($"Dash Action: {action}");

                if (action == "navigate_to_editor")
                {
                    NavigateToEditor();
                }
                else if (action == "navigate_to_home")
                {
                    NavigateToHome();
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine($"Unknown dash action: {action}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error handling dash web message: {ex.Message}");
            }
        }

        private async void SetupConsoleMonitoring()
        {
            try
            {
                string exeDirectory = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                string workspaceDirectory = System.IO.Path.Combine(exeDirectory, "Workspace");
                consoleFilePath = System.IO.Path.Combine(workspaceDirectory, "output.log");

                if (!Directory.Exists(workspaceDirectory))
                {
                    Directory.CreateDirectory(workspaceDirectory);
                }

                string timestamp = DateTime.Now.ToString("HH:mm:ss");
                string initMessage = $"[INFO] {timestamp} -- Console Initialised{Environment.NewLine}";
                await File.WriteAllTextAsync(consoleFilePath, initMessage);
                lastConsoleContent = initMessage;

                await UpdateConsoleDisplay(initMessage);

                fileWatcher = new FileSystemWatcher(workspaceDirectory, "output.log")
                {
                    NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size,
                    EnableRaisingEvents = true
                };
                fileWatcher.Changed += OnConsoleFileChanged;

                consoleTimer = new System.Windows.Threading.DispatcherTimer();
                consoleTimer.Interval = TimeSpan.FromSeconds(1);
                consoleTimer.Tick += (s, e) => ReadConsoleFile();
                consoleTimer.Start();

                ReadConsoleFile();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error setting up console monitoring: {ex.Message}");
            }
        }

        private void OnConsoleFileChanged(object sender, FileSystemEventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                ReadConsoleFile();
            }));
        }

        private async void ReadConsoleFile()
        {
            try
            {
                if (!File.Exists(consoleFilePath))
                {
                    return;
                }

                string content = await File.ReadAllTextAsync(consoleFilePath);

                if (content != lastConsoleContent)
                {
                    lastConsoleContent = content;
                    await UpdateConsoleDisplay(content);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error reading console file: {ex.Message}");
            }
        }

        private async Task UpdateConsoleDisplay(string content)
        {
            try
            {
                if (Console?.CoreWebView2 == null)
                    return;

                string escapedContent = EscapeForJavaScript(content);

                string script = $"if (typeof updateConsoleContent === 'function') {{ updateConsoleContent(`{escapedContent}`); }}";
                await Console.CoreWebView2.ExecuteScriptAsync(script);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error updating console display: {ex.Message}");
            }
        }

        private string EscapeForJavaScript(string input)
        {
            if (string.IsNullOrEmpty(input))
                return "";

            return input.Replace("\\", "\\\\")
                       .Replace("`", "\\`")
                       .Replace("$", "\\$")
                       .Replace("\r\n", "\\n")
                       .Replace("\n", "\\n")
                       .Replace("\r", "\\r")
                       .Replace("\t", "\\t")
                       .Replace("'", "\\'")
                       .Replace("\"", "\\\"");
        }


        public async void ClearConsole()
        {
            try
            {
                if (File.Exists(consoleFilePath))
                {
                    await File.WriteAllTextAsync(consoleFilePath, "");
                }

                if (Console?.CoreWebView2 != null)
                {
                    await Console.CoreWebView2.ExecuteScriptAsync("if (typeof clearConsole === 'function') { clearConsole(); }");
                }

                lastConsoleContent = "";
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error clearing console: {ex.Message}");
            }
        }

        public async void WriteToConsole(string logType, string message)
        {
            try
            {
                string timestamp = DateTime.Now.ToString("HH:mm:ss");
                string logEntry = $"[{logType.ToUpper()}] {timestamp} -- {message}{Environment.NewLine}";

                await File.AppendAllTextAsync(consoleFilePath, logEntry);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error writing to console: {ex.Message}");
            }
        }

        private async void OnSidebarMessageReceived(object sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                var message = JsonConvert.DeserializeObject<dynamic>(e.TryGetWebMessageAsString());
                string messageType = message.type;

                switch (messageType)
                {
                    case "requestScriptList":
                        await SendScriptListToSidebar();
                        break;

                    case "loadScript":
                        string scriptName = message.name;
                        await LoadScriptFromFile(scriptName);
                        break;

                    case "refreshScripts":
                        await SendScriptListToSidebar();
                        break;

                    case "requestEditorContent":
                        await SendEditorContentToSidebar();
                        break;

                    case "loadRecentScript":
                        string content = message.content;
                        await LoadScriptContent(content);
                        break;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error handling sidebar message: {ex.Message}");
            }
        }

        private async Task SendScriptListToSidebar()
        {
            try
            {
                var scriptFiles = Directory.GetFiles(scriptsDirectory, "*.lua")
                    .Concat(Directory.GetFiles(scriptsDirectory, "*.luau"))
                    .Concat(Directory.GetFiles(scriptsDirectory, "*.txt"))
                    .Select(System.IO.Path.GetFileName)
                    .ToArray();

                var response = new
                {
                    type = "scriptList",
                    files = scriptFiles,
                    count = scriptFiles.Length
                };

                Sidebar.CoreWebView2.PostWebMessageAsJson(JsonConvert.SerializeObject(response));
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error sending script list: {ex.Message}");
            }
        }

        private async Task LoadScriptFromFile(string fileName)
        {
            try
            {
                string filePath = System.IO.Path.Combine(scriptsDirectory, fileName);
                if (File.Exists(filePath))
                {
                    string content = await File.ReadAllTextAsync(filePath);
                    await LoadScriptContent(content);
                    var response = new
                    {
                        type = "scriptLoaded",
                        fileName = fileName,
                        success = true
                    };
                    Sidebar.CoreWebView2.PostWebMessageAsJson(JsonConvert.SerializeObject(response));
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading script: {ex.Message}");
                var response = new
                {
                    type = "scriptLoaded",
                    fileName = fileName,
                    success = false,
                    error = ex.Message
                };
                Sidebar.CoreWebView2.PostWebMessageAsJson(JsonConvert.SerializeObject(response));
            }
        }

        private async Task LoadScriptContent(string content)
        {
            try
            {
                string escapedContent = content
                    .Replace("\\", "\\\\")
                    .Replace("`", "\\`")
                    .Replace("${", "\\${");

                await Editor.CoreWebView2.ExecuteScriptAsync($"editor.setValue(`{escapedContent}`);");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading script content: {ex.Message}");
            }
        }

        private async Task SendEditorContentToSidebar()
        {
            try
            {
                string scriptContent = await Editor.ExecuteScriptAsync("GetText();");
                string rawContent = JsonConvert.DeserializeObject<string>(scriptContent);

                var response = new
                {
                    type = "recentScript",
                    content = rawContent
                };

                Sidebar.CoreWebView2.PostWebMessageAsJson(JsonConvert.SerializeObject(response));

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error sending editor content: {ex.Message}");
            }
        }

        private async Task LoadApplicationContent()
        {
            if (Main != null)
                Main.Visibility = Visibility.Visible;
        }

        public bool IsInitialized => _isInitialized;

        private void AddDropShadow()
        {
            var dropShadow = new System.Windows.Media.Effects.DropShadowEffect
            {
                Color = Colors.Black,
                Direction = 270,
                ShadowDepth = 5,
                BlurRadius = 15,
                Opacity = 0.3
            };

            this.Effect = dropShadow;
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                ToggleMaximize();
            }
            else
            {
                DragMove();
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            AnimateClose();
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            ToggleMaximize();
        }

        private void ToggleMaximize()
        {
            if (_isMaximized)
            {
                RestoreWindow();
            }
            else
            {
                MaximizeWindow();
            }
        }

        private void MaximizeWindow()
        {
            if (!_isMaximized)
            {
                _normalBounds = new Rect(Left, Top, Width, Height);
                var workingArea = SystemParameters.WorkArea;
                AnimateResize(workingArea.Left, workingArea.Top,
                             workingArea.Width, workingArea.Height);
                _isMaximized = true;
                UpdateMaximizeButtonIcon();
            }
        }

        private void RestoreWindow()
        {
            if (_isMaximized)
            {
                AnimateResize(_normalBounds.Left, _normalBounds.Top,
                             _normalBounds.Width, _normalBounds.Height);
                _isMaximized = false;
                UpdateMaximizeButtonIcon();
            }
        }

        private void AnimateResize(double left, double top, double width, double height)
        {
            var duration = TimeSpan.FromMilliseconds(200);
            var easing = new QuadraticEase { EasingMode = EasingMode.EaseOut };

            var leftAnimation = new DoubleAnimation(Left, left, duration) { EasingFunction = easing };
            var topAnimation = new DoubleAnimation(Top, top, duration) { EasingFunction = easing };
            var widthAnimation = new DoubleAnimation(Width, width, duration) { EasingFunction = easing };
            var heightAnimation = new DoubleAnimation(Height, height, duration) { EasingFunction = easing };

            this.BeginAnimation(Window.LeftProperty, leftAnimation);
            this.BeginAnimation(Window.TopProperty, topAnimation);
            this.BeginAnimation(Window.WidthProperty, widthAnimation);
            this.BeginAnimation(Window.HeightProperty, heightAnimation);
        }

        private void AnimateClose()
        {
            if (Editor != null)
                Editor.Visibility = Visibility.Collapsed;
            Sidebar.Visibility = Visibility.Collapsed;
            Console.Visibility = Visibility.Collapsed;

            var scaleTransform = new ScaleTransform(1, 1);
            var opacityAnimation = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(150));
            var scaleAnimation = new DoubleAnimation(1, 0.8, TimeSpan.FromMilliseconds(150));

            this.RenderTransform = scaleTransform;
            this.RenderTransformOrigin = new Point(0.5, 0.5);

            opacityAnimation.Completed += (s, e) => this.Close();

            this.BeginAnimation(Window.OpacityProperty, opacityAnimation);
            scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnimation);
            scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleAnimation);
        }

        private void UpdateMaximizeButtonIcon()
        {
            var maximizeIcon = FindName("MaximizeIcon") as System.Windows.Shapes.Path;
            if (maximizeIcon != null)
            {
                if (_isMaximized)
                {
                    maximizeIcon.Data = Geometry.Parse("M2,2 L8,2 L8,8 L2,8 L2,2 M4,4 L10,4 L10,10 L4,10 L4,4");
                }
                else
                {
                    maximizeIcon.Data = Geometry.Parse("M3,3 L9,3 L9,9 L3,9 L3,3 M4,4 L8,8 M8,4 L4,8");
                }
            }
        }

        private void TrafficLight_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is Button button)
            {
                var iconName = button.Name switch
                {
                    "CloseButton" => "CloseIcon",
                    "MinimizeButton" => "MinimizeIcon",
                    "MaximizeButton" => "MaximizeIcon",
                    _ => null
                };

                if (iconName != null)
                {
                    var icon = FindName(iconName) as System.Windows.Shapes.Path;
                    if (icon != null)
                    {
                        var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(150));
                        icon.BeginAnimation(UIElement.OpacityProperty, fadeIn);
                    }
                }
            }
        }

        private void TrafficLight_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is Button button)
            {
                var iconName = button.Name switch
                {
                    "CloseButton" => "CloseIcon",
                    "MinimizeButton" => "MinimizeIcon",
                    "MaximizeButton" => "MaximizeIcon",
                    _ => null
                };

                if (iconName != null)
                {
                    var icon = FindName(iconName) as System.Windows.Shapes.Path;
                    if (icon != null)
                    {
                        var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(150));
                        icon.BeginAnimation(UIElement.OpacityProperty, fadeOut);
                    }
                }
            }
        }

        private void ResizeGrip_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!_isMaximized)
            {
                _isResizing = true;
                var hwndSource = PresentationSource.FromVisual(this) as HwndSource;
                if (hwndSource != null)
                {
                    ReleaseCapture();
                    SendMessage(hwndSource.Handle, WM_SYSCOMMAND, SC_SIZE + WMSZ_BOTTOMRIGHT, 0);
                }
                _isResizing = false;
            }
        }

        private void MacWindow_StateChanged(object sender, EventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
            {
                if (_isMaximized)
                {
                    _isMaximized = false;
                    UpdateMaximizeButtonIcon();
                }
                this.Opacity = 1;
            }
        }

        private void MacWindow_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (!_isMaximized && !_isResizing && this.WindowState == WindowState.Normal)
            {
                _normalBounds = new Rect(Left, Top, Width, Height);
            }
        }

        private void MacWindow_LocationChanged(object sender, EventArgs e)
        {
            if (!_isMaximized && !_isResizing && this.WindowState == WindowState.Normal)
            {
                _normalBounds = new Rect(Left, Top, Width, Height);
            }
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            var hwndSource = PresentationSource.FromVisual(this) as HwndSource;
            hwndSource?.AddHook(WndProc);
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            switch (msg)
            {
                case 0x0024:
                    WmGetMinMaxInfo(hwnd, lParam);
                    handled = true;
                    break;
            }
            return IntPtr.Zero;
        }

        private void WmGetMinMaxInfo(IntPtr hwnd, IntPtr lParam)
        {
            var mmi = (MINMAXINFO)Marshal.PtrToStructure(lParam, typeof(MINMAXINFO));

            var monitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
            if (monitor != IntPtr.Zero)
            {
                var monitorInfo = new MONITORINFO();
                GetMonitorInfo(monitor, monitorInfo);

                var rcWorkArea = monitorInfo.rcWork;
                var rcMonitorArea = monitorInfo.rcMonitor;

                mmi.ptMaxPosition.x = Math.Abs(rcWorkArea.left - rcMonitorArea.left);
                mmi.ptMaxPosition.y = Math.Abs(rcWorkArea.top - rcMonitorArea.top);
                mmi.ptMaxSize.x = Math.Abs(rcWorkArea.right - rcWorkArea.left);
                mmi.ptMaxSize.y = Math.Abs(rcWorkArea.bottom - rcWorkArea.top);
            }

            Marshal.StructureToPtr(mmi, lParam, true);
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int x;
            public int y;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MINMAXINFO
        {
            public POINT ptReserved;
            public POINT ptMaxSize;
            public POINT ptMaxPosition;
            public POINT ptMinTrackSize;
            public POINT ptMaxTrackSize;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public class MONITORINFO
        {
            public int cbSize = Marshal.SizeOf(typeof(MONITORINFO));
            public RECT rcMonitor = new RECT();
            public RECT rcWork = new RECT();
            public int dwFlags = 0;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 0)]
        public struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        [DllImport("user32")]
        internal static extern bool GetMonitorInfo(IntPtr hMonitor, MONITORINFO lpmi);

        [DllImport("user32")]
        internal static extern IntPtr MonitorFromWindow(IntPtr handle, int flags);

        private const int MONITOR_DEFAULTTONEAREST = 0x00000002;
    }
}